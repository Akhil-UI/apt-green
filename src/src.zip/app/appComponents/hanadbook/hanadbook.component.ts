import { Component } from '@angular/core';

@Component({
  selector: 'app-hanadbook',
  templateUrl: './hanadbook.component.html',
  styleUrls: ['./hanadbook.component.scss']
})
export class HanadbookComponent {

}
